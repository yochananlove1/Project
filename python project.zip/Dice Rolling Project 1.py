import random
game_start = input('would you like to roll the dice?\n')

def dice_roll():
    print ('Your number is: ' + str(random.randint(1,6)))
    global play_again
    play_again = input ('would you like to play again?\n')

if game_start =='yes':
    dice_roll()
    while play_again == 'yes':
        dice_roll()
        if play_again == 'no':
            print ('Game Over')
